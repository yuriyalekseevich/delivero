## 2.3.0

  * Implements `isPresent` that always returns true.

## 2.2.0

  * Updates `geocoding_platform_interface` to version 3.1.0.
  * Updates minimal iOS version of the example application to 12.

## 2.1.1

* Removes obsolete version check in `toPlacemarkDictionary`. This removes kABPersonAddressStreetKey deprecation warning from occurring.

## 2.1.0

* Splits from `geocoding` as a federated implementation.
