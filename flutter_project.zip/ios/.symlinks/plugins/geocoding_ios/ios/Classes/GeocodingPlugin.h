//
//  GeocodingPlugin.h
//  geocoding
//
//  Created by Maurits van Beusekom on 07/06/2020.
//

#import <Flutter/Flutter.h>

@interface GeocodingPlugin : NSObject<FlutterPlugin>
@end
