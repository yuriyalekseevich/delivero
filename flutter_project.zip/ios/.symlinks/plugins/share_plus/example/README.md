# share_example

Demonstrates how to use the share_plus plugin.
